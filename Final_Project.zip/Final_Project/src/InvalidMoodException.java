public class InvalidMoodException extends Exception {
    public InvalidMoodException() {
        super();
    }
}